package parcialito2;

@Melodia
public class MelodiaDePrueba {
	@Escala({"C", "D", "E", "F", "G", "A", "B"})
	private String escala;
	
	@Duracion({"w", "h", "q", "i", "s", "t", "x", "n"})
	private String duracion;
}
